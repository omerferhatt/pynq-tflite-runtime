__version__ = '2.5.0'
__git_version__ = '0.6.0-103303-g48a4bf66915'
